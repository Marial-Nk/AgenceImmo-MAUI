﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class ChinookDataProvider
    {
        // Exécution de requêtes complexe via ADO.NET

        // Appel à des procédures stockées
    }
}
