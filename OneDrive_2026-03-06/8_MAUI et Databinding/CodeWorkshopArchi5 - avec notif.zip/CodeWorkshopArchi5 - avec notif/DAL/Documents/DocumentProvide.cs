﻿using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Documents
{
    public class DocumentProvider
    {
        public static byte[] GetDocument(Common.Enums.DocumentType docType, int docRelatedObjectId)
        {
            string documentFileName = $"document_{docType}_{docRelatedObjectId}";

            var filePath = System.IO.Path.Combine(GetDocStoreFilePath(), documentFileName);

            return System.IO.File.ReadAllBytes(filePath);
        }

        // public static void AddDocument(....);

        static string GetDocStoreFilePath()
        {
            return Common.Utilities.AppSettingsHelper.GetSettingValue("DocumentStorePath");
        }
    }
}
