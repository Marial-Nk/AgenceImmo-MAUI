﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BU.Services
{
    public class InvoicingService
    {
        public static Entities.DetailedInvoice? GetDetailedInvoice(int invoiceID)
        {
            var detailedInvoice = new Entities.DetailedInvoice();

            using (var db = new DAL.DB.ChinookContext())
            {
                var invoice = db.Invoices.SingleOrDefault(i => i.InvoiceId == invoiceID);
                if (invoice == null)
                    return null;

                detailedInvoice.Invoice = invoice;
                detailedInvoice.Lines = invoice.InvoiceLines.ToList();

                detailedInvoice.PDFInvoice = DAL.Documents.DocumentProvider.GetDocument(Common.Enums.DocumentType.Invoice, invoiceID);
            }

            return detailedInvoice;
        }
    }
}
