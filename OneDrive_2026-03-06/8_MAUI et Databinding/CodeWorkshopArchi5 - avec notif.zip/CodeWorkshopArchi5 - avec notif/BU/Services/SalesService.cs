﻿using Azure.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BU.Services
{
    public class SalesService
    {
        /// <summary>
        /// Retourne le niveau d'importance d'un client basé sur le nombre de factures
        /// </summary>
        /// <param name="customerID"></param>
        /// <returns></returns>
        public static Enums.CustomerImportanceLevel GetCustomerImportanceLevel(int customerID)
        {
            using (var db = new DAL.DB.ChinookContext())
            {
                var customer = db.Customers.SingleOrDefault(c => c.CustomerId == customerID);
                if (customer == null)
                    return Enums.CustomerImportanceLevel.None;

                var invoiceCount = customer.Invoices.Count();

                if (invoiceCount < Constants.PremiumImportanceLevelMinInvoice)
                    return Enums.CustomerImportanceLevel.Regular;
                else if (invoiceCount > Constants.PremiumImportanceLevelMaxInvoice)
                    return Enums.CustomerImportanceLevel.VIP;
                else
                    return Enums.CustomerImportanceLevel.Premium;
            }
        }
    }
}
