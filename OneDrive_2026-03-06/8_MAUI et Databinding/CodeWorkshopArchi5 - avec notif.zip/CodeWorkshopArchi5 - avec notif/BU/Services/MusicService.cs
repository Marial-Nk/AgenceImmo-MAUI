﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BU.Services
{
    public class MusicService
    {
        public static List<DAL.DB.Artist> GetArtists()
        {
            using (var db = new DAL.DB.ChinookContext())
            {
                return db.Artists.ToList();
            }
        }

        public static DAL.DB.Artist? GetArtist(int artistId)
        {
            using (var db = new DAL.DB.ChinookContext())
            {
                return db.Artists.SingleOrDefault(a => a.ArtistId == artistId);
            }
        }

        public static void AddArtist(DAL.DB.Artist newArtist)
        {
            using (var db = new DAL.DB.ChinookContext())
            {
                db.Artists.Add(newArtist);
                db.SaveChanges();
            }
        }

        public static void UpdateArtist(DAL.DB.Artist artist)
        {
            using (var db = new DAL.DB.ChinookContext())
            {
                //db.Update(artist);

                var artistToUpdate = db.Artists.FirstOrDefault(a => a.ArtistId == artist.ArtistId);
                if (artistToUpdate != null)
                {
                    artistToUpdate.Name = artist.Name;

                    db.SaveChanges();
                }
            }
        }

        public static void RemoveArtist(int artistId)
        {
            using (var db = new DAL.DB.ChinookContext())
            {
                var artistToRemove = db.Artists.FirstOrDefault(a => a.ArtistId == artistId);
                if (artistToRemove != null)
                {
                    db.Artists.Remove(artistToRemove);
                    db.SaveChanges();
                }
            }
        }

        public static List<DAL.DB.Album> GetArtistAlbums(int artistID)
        {
            using (var db = new DAL.DB.ChinookContext())
            {
                return db.Albums.Where(a => a.ArtistId == artistID).ToList();
            }
        }
    }
}
