﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BU.Entities
{
    public class DetailedInvoice
    {
        public DAL.DB.Invoice Invoice { get; set; }

        public List<DAL.DB.InvoiceLine> Lines { get; set; }

        public byte[] PDFInvoice { get; set; }
    }
}
