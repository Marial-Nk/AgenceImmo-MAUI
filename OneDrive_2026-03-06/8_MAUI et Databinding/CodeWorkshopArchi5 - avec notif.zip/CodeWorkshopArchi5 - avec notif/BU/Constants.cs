﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BU
{
    public class Constants
    {
        public const int PremiumImportanceLevelMinInvoice = 5;
        public const int PremiumImportanceLevelMaxInvoice = 10;
    }
}
