﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BU.Enums
{

    public enum CustomerImportanceLevel
    {
        None = 0,
        Regular = 1,
        Premium = 2,
        VIP = 3
    }
}
