﻿namespace ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var artistes = BU.Services.MusicService.GetArtists();
            foreach (var artiste in artistes) 
                Console.WriteLine(artiste.Name);


        }
    }
}
