﻿using MyMauiApp.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MyMauiApp.ViewModels
{
    /// <summary>
    /// Le view model implémente l'interface INotifyPropertyChanged
    /// pour pouvoir notifier la vue des changements du nom de l'artiste.
    /// On utilise une ObservableCollection pour la liste des albums
    /// afin d'aussi notifier la vue des changements.
    /// </summary>
    public class ArtistPageViewModel : INotifyPropertyChanged
    {
        public string? Title { get; set; }
        public int ArtistId { get; set; }

        private string artistName;
        public string? ArtistName
        {
            get => artistName;
            set
            {
                artistName = value;
                NotifyPropertyChanged();
            }
        }


        public int AlbumCount => Albums.Count();

        public ObservableCollection<DAL.DB.Album> Albums { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChanged([CallerMemberName] string propertyName = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

    }
}
