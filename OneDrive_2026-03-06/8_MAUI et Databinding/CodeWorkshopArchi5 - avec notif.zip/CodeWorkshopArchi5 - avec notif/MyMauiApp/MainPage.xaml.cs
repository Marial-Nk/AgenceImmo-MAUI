﻿namespace MyMauiApp
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public MainPage()
        {
            InitializeComponent();

            ArtistList.ItemsSource = BU.Services.MusicService.GetArtists();
        }


    }
}
