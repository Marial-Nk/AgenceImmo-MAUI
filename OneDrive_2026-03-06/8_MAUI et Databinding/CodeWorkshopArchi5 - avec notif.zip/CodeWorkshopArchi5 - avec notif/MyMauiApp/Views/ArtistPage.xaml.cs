
using DAL.DB;
using System.Collections.ObjectModel;

namespace MyMauiApp.Views;

public partial class ArtistPage : ContentPage
{
	ViewModels.ArtistPageViewModel artistVM { get; set; }
	public ArtistPage()
	{
		InitializeComponent();
		PopulateAndBind();
	}

    private void PopulateAndBind()
    {
		int artistID = 22;
		var artist = BU.Services.MusicService.GetArtist(artistID);
		if (artist == null)
			return;

		var albums = BU.Services.MusicService.GetArtistAlbums(artistID);

		artistVM = new ViewModels.ArtistPageViewModel()
		{
			Title = $"Artiste - {artist.Name}",
			ArtistId = artistID,
			ArtistName = artist.Name,
			Albums = new ObservableCollection<Album>(albums),
		};

		this.BindingContext = artistVM;
    }

    private void SaveButton_Clicked(object sender, EventArgs e)
    {
		string newArtistName = artistVM.ArtistName;
		// BU.Services.MusicService.UpdateArtistName(artistVM.ArtistId, artistVM.ArtistName);
    }

    private void TestUpdateVMButton_Clicked(object sender, EventArgs e)
    {
		// Tests de l'impact de modifications du ViewModel dans le code behind
		// apr�s impl�mentation de l'interface INotifyPropertyChanged et 
		// de l'observable collection

        // Modification d'une propri�t� du ViewModel
        // Constat: mise � jour du nom de l'artiste dans la vue: ok
        artistVM.ArtistName = "Blabla";

		// Modification d'une liste du ViewModel bind�e avec une ItemSource
		// Constat: mise � jour de la liste d'albiums dans la vue: ok
		artistVM.Albums.Add(new DAL.DB.Album() { AlbumId = 999, ArtistId = 1, Title = "Nouvel Album" });
    }
}