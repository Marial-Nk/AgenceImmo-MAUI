﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyMauiApp.ViewModels
{
    public class ArtistPageViewModel
    {
        public string? Title { get; set; }
        public int ArtistId { get; set; }

        public string ArtistName { get; set; }

        public int AlbumCount => Albums.Count();

        public List<DAL.DB.Album> Albums { get; set; }
    }
}
