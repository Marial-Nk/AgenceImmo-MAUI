
namespace MyMauiApp.Views;

public partial class ArtistPage : ContentPage
{
	ViewModels.ArtistPageViewModel artistVM { get; set; }
	public ArtistPage()
	{
		InitializeComponent();
		PopulateAndBind();
	}

    private void PopulateAndBind()
    {
		int artistID = 22;
		var artist = BU.Services.MusicService.GetArtist(artistID);
		if (artist == null)
			return;

		var albums = BU.Services.MusicService.GetArtistAlbums(artistID);

		artistVM = new ViewModels.ArtistPageViewModel()
		{
			Title = $"Artiste - {artist.Name}",
			ArtistId = artistID,
			ArtistName = artist.Name,
			Albums = albums,
		};

		this.BindingContext = artistVM;
    }

    private void SaveButton_Clicked(object sender, EventArgs e)
    {
		string newArtistName = artistVM.ArtistName;
		// BU.Services.MusicService.UpdateArtistName(artistVM.ArtistId, artistVM.ArtistName);
    }

    private void TestUpdateVMButton_Clicked(object sender, EventArgs e)
    {
		// Tests de l'impact de modifications du ViewModel dans le code behind

        // Modification d'une propri�t� du ViewModel
        // Constat: pas de mise � jour du nom de l'artiste dans la vue
        artistVM.ArtistName = "Blabla";

		// Modification d'une liste du ViewModel bind�e avec une ItemSource
		// Constat: pas de mise � jour de la liste d'albiums dans la vue
		artistVM.Albums.Add(new DAL.DB.Album() { AlbumId = 999, ArtistId = 1, Title = "Nouvel Album" });

		// R�ponse voir dans la notion de notification
    }
}