
namespace BaseMauiApp;

public partial class UsersPage : ContentPage
{
	ViewModels.UsersPageViewModel vm { get; set; }
	public UsersPage()
	{
		InitializeComponent();

		PopulateAndBind();
	}

    private void PopulateAndBind()
    {
		vm = new ViewModels.UsersPageViewModel();
		vm.PageTitle = "Liste des utilisateurs";
		vm.Users = new List<ViewModels.User>();
		vm.Users.Add(new ViewModels.User { FirstName = "Thierry", LastName = "Libert" });
        vm.Users.Add(new ViewModels.User { FirstName = "Arnaud", LastName = "Guillaume" });

		this.BindingContext = vm;
    }
}