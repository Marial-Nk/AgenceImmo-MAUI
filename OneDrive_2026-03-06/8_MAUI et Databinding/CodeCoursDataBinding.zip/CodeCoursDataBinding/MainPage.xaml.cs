﻿

namespace BaseMauiApp
{
    public partial class MainPage : ContentPage
    {
        public string WelcomeMessage { get; set; }
        public List<Personne> Personnes { get; set; }

        public MainPage()
        {
            InitializeComponent();

            Binding sliderBinding = new Binding();
            sliderBinding.Source = TestSlider;
            sliderBinding.Path = "Value";
            MyLabel.SetBinding(Label.TextProperty, sliderBinding);

            WelcomeMessage = "Bienvenue dans la page de test du data binding MAUI";
            WelcomeLabel.BindingContext = WelcomeMessage;

            var unePersonne = new Personne() { FirstName = "Thierry", LastName = "Libert" };
            //MainLayout.BindingContext = unePersonne;
            this.BindingContext = unePersonne;

            Personnes = new List<Personne>();
            Personnes.Add(unePersonne);
            Personnes.Add(new Personne() { FirstName="Jeanne", LastName="Dupuis" });
            PersonneCollectionView.ItemsSource = Personnes;

        }


    }
}
