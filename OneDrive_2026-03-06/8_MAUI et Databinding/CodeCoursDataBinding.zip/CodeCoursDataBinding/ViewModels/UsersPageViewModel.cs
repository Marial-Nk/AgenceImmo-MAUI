﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseMauiApp.ViewModels
{
    public class UsersPageViewModel
    {
        public string PageTitle { get; set; }
        public List<User> Users { get; set; }
        public int UserCount => Users.Count;
    }
}
