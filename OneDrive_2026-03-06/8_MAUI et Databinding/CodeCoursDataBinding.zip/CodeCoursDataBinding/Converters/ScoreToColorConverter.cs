﻿
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseMauiApp.Converters
{
    public class ScoreToColorConverter : IValueConverter
    {
        public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            int score;
            if (int.TryParse((string) value, out score))
            {
                if (score < 50)
                    return Colors.Red;
                else if (score < 80)
                    return Colors.Orange;
                return Colors.Green;
        
            }
            return Colors.Transparent;
        }

        public object? ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
